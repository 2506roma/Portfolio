


https://user-images.githubusercontent.com/92484982/167226091-cb4ee2cb-f797-4ad4-a3bd-378323fbfe74.mp4



# Projeto: portfólio
Projeto utilizando HTML, CSS e JS puro que visa uma pagina completa de portfólio pessoal.



## Tarefas

O controle de tarefas será realizado no GitHub


## Ícones

* :mosquito: correção de bug
* :package: nova funcionalidade
* :up: atualização
* :checkered_flag: release

